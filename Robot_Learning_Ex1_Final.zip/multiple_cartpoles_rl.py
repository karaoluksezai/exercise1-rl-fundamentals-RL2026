import argparse
import numpy as np
from cartpole_rl import train_feedback


def repeat_shuttle(num_runs, train_episodes):
    models, histories = [], []
    for seed in range(num_runs):
        model, history = train_feedback("shuttle", seed, train_episodes)
        models.append(model)
        histories.append(history)
    return models, np.asarray(histories)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--num_runs", type=int, default=10)
    p.add_argument("--train_episodes", type=int, default=60)
    args = p.parse_args()
    _, runs = repeat_shuttle(args.num_runs, args.train_episodes)
    import matplotlib.pyplot as plt
    x = np.arange(1, runs.shape[1]+1)
    plt.plot(x, runs.mean(axis=0))
    plt.fill_between(x, runs.mean(axis=0)-runs.std(axis=0), runs.mean(axis=0)+runs.std(axis=0), alpha=.2)
    plt.xlabel("Training episode")
    plt.ylabel("Shuttle return")
    plt.show()
