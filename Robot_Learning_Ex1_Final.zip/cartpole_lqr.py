"""
    Robot Learning
    Exercise 1

    Linear Quadratic Regulator

    Polito A-Y 2026-2027
"""
import gymnasium as gym
import numpy as np
from scipy import linalg     # get riccati solver
import argparse
import matplotlib.pyplot as plt
import sys
from utils import get_space_dim, set_seed
import pdb 
import time

# Parse script arguments
def parse_args(args=sys.argv[1:]):
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="CartPole-v1",
                        help="Environment to use")
    parser.add_argument('--seed', default=0, type=int, help='Random seed')
    parser.add_argument("--time_sleep", action='store_true',
                        help="Add timer for visualizing rendering with a slower frame rate")
    parser.add_argument("--mode", type=str, default="control",
                        help="Type of test ['control', 'multiple_R']")
    return parser.parse_args(args)

def linerized_cartpole_system(mp, mk, lp, g=9.81):
    mt=mp+mk
    # state matrix
    # a1 = 0
    a1 = (g*mp)/((mk + mp)*(mp/(mk + mp) - 4/3))
    a2 = - g /(lp*((mp/mt)-4/3))
    
    A = np.array([[0, 1, 0,  0],
                  [0, 0, a1, 0],
                  [0, 0, 0,  1],
                  [0, 0, a2, 0]])

    # input matrix
    # b1 = 1/mt
    b1 = -(mp/(mt*(mp/mt - 4/3)) - 1)/mt
    b2 = 1 / (lp*mt*((mp/mt)-4/3))
    B = np.array([[0], [b1], [0], [b2]])
    
    return A, B

def optimal_controller(A, B, R_value=1):
    R = R_value*np.eye(1, dtype=int)  # choose R (weight for input)
    Q = 5*np.eye(4, dtype=int)        # choose Q (weight for state)
   # solve ricatti equation
    P = linalg.solve_continuous_are(A, B, Q, R)

    # calculate optimal controller gain
    K = np.dot(np.linalg.inv(R),
            np.dot(B.T, P))
    return K

def apply_state_controller(K, x):
    # feedback controller
    # K is 1x4, so Kx is a length-1 array; the controller needs a scalar force
    u = np.asarray(-np.dot(K, x)).item()   # u = -Kx
    if u > 0:
        return 1, u     # if force_dem > 0 -> move cart right
    else:
        return 0, u     # if force_dem <= 0 -> move cart left

def simulate(R=1., steps=1000, seed=0, render=False):
    env = gym.make("CartPole-v1", max_episode_steps=steps,
                   render_mode="human" if render else None)
    pole = env.unwrapped
    A, B = linerized_cartpole_system(pole.masspole, pole.masscart, pole.length, pole.gravity)
    K = optimal_controller(A, B, R)
    state, _ = env.reset(seed=seed)
    history, forces = [], []
    for _ in range(steps):
        action, demand = apply_state_controller(K, state)
        applied = float(np.clip(demand, -10, 10))
        pole.force_mag = abs(applied)
        state, _, terminated, truncated, _ = env.step(action)
        history.append(state.copy())
        forces.append(applied)
        if terminated or truncated:
            break
    env.close()
    return np.asarray(history), np.asarray(forces)


def draw_states(seed=0):
    states, _ = simulate(seed=seed)
    fig, axes = plt.subplots(2, 2, figsize=(9, 5), sharex=True)
    for ax, series, label in zip(axes.flat, states.T,
            ["Cart position (m)", "Cart velocity (m/s)", "Pole angle (rad)", "Angular velocity (rad/s)"]):
        ax.plot(np.arange(1, len(states)+1), series)
        ax.axhspan(-.003, .003, alpha=.17, color="green")
        ax.set(xlabel="Timestep", ylabel=label)
    fig.tight_layout()
    return states


def draw_forces(seed=0):
    fig, ax = plt.subplots(figsize=(8, 4))
    for r in [.01, .1, 10, 100]:
        _, f = simulate(r, 500, seed)
        ax.plot(np.arange(1, len(f)+1), -f if f[0] > 0 else f, label=f"R={r:g}")
    ax.set(xlabel="Timestep", ylabel="Sign-aligned applied force (N)")
    ax.legend()
    fig.tight_layout()


if __name__ == "__main__":
    args = parse_args()
    if args.mode == "control":
        draw_states(args.seed)
    else:
        draw_forces(args.seed)
    plt.show()
