import numpy as np
import torch
from cartpole_rl import train_normal, train_feedback, evaluate
from multiple_cartpoles_rl import repeat_shuttle


def run_experiments():
    rates = [1e-5, 1e-4, 1e-3, 1e-2, 1e-1]
    curves, scores = [], []
    for lr in rates:
        runs, tests = [], []
        for seed in range(3):
            model, history = train_normal(lr, seed)
            if lr == .01 and seed == 0:
                torch.save(model, "CartPole-v1_params.ai")
            runs.append(history)
            tests.append(evaluate(model)[:, 0])
        curves.append(runs)
        scores.append(tests)
        print("Completed learning rate", lr, flush=True)
    model, random_history = train_normal(.01, 0, True)
    random_test = evaluate(model)
    custom = []
    custom_curves = []
    models, shuttle_runs = repeat_shuttle(10, 60)
    for mode in ["center", "target", "shuttle"]:
        if mode == "shuttle":
            model = models[0]
            custom_curves.append(shuttle_runs[0])
        else:
            model, history = train_feedback(mode, 0, 60, .75 if mode == "target" else 0.)
            custom_curves.append(history)
        torch.save(model, mode+".ai")
        custom.append(evaluate(model))
    np.savez("measurements.npz", rates=rates, curves=curves, scores=scores,
             random_history=random_history, random_test=random_test, custom=custom, custom_curves=custom_curves, shuttle_runs=shuttle_runs)


if __name__ == "__main__":
    run_experiments()
