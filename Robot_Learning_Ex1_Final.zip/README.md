# Robot Learning — Exercise 1
Open report_lab1_2026_completed.ipynb for the completed English report. Its graphs are embedded and are also available in figures/. The notebook and data files belong in the same directory.

## Reproduce
Use Python 3.11 in a virtual environment. Run these commands from this folder.

    python -m pip install -r requirements.txt
    python experiments.py

The experiment driver reproduces measurements.npz and four PyTorch checkpoints. rewards.pkl contains a pandas DataFrame of the ten shuttle training histories. Re-run the notebook to display the plots.

## Test a trained model
    python cartpole_rl.py -t CartPole-v1_params.ai
    python cartpole_rl.py -t center.ai
    python cartpole_rl.py -t target.ai
    python cartpole_rl.py -t shuttle.ai --render_test

The default checkpoint is the normal-policy baseline. The other three contain neural policies for three separate reward functions. Each checkpoint includes its task and target along with the network weights. Custom policy initialization and target-relative inputs are described in section 4.3 of the report.

## Repeat individual experiments
    python cartpole_lqr.py --mode control
    python cartpole_lqr.py --mode multiple_R
    python cartpole_rl.py --mode target --central_point 0.75 --train_episodes 60
    python multiple_cartpoles_rl.py --num_runs 10 --train_episodes 60

In Colab, extract the ZIP into the runtime working directory before executing the notebook. Saved results can be read without retraining.
