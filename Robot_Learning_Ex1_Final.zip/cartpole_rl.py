"""CartPole experiments. Commands run from the folder containing this file."""
import argparse
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch

from agent import Policy

torch.set_num_threads(1)


def reward_value(mode, state, target, direction):
    x, velocity, angle, _ = state
    if mode == "normal":
        return 1.0
    if mode == "shuttle":
        return 1 + direction * velocity - 3 * angle**2
    return 1 - (x - target)**2 - 3 * angle**2


def evaluate(model, episodes=30, render=False, steps=500):
    env = gym.make("CartPole-v1", max_episode_steps=steps,
                   render_mode="human" if render else None)
    rows = []
    mode = model["mode"]
    policy = Policy(4, 2)
    policy.load_state_dict(model["weights"])
    w1, b1, w2, b2 = [p.detach().numpy() for p in policy.parameters()]
    for seed in range(episodes):
        state, _ = env.reset(seed=10000 + seed)
        direction = 1
        total = 0
        path = []
        switches = 0
        for t in range(steps):
            target = model.get("target", 0)
            if mode == "shuttle":
                target = direction * model["amplitude"]
            features = state.copy()
            features[0] -= target
            action = int((w2 @ np.maximum(w1 @ features + b1, 0) + b2).argmax())
            state, _, terminated, truncated, _ = env.step(action)
            total += reward_value(mode, state, target, direction)
            path.append(state.copy())
            if mode == "shuttle" and direction * state[0] >= model["threshold"]:
                direction *= -1
                switches += 1
            if terminated or truncated:
                break
        path = np.asarray(path)
        rows.append([len(path), total, np.abs(path[:, 1]).max(), switches,
                     path[:, 0].min(), path[:, 0].max(),
                     np.mean(np.abs(path[:, 0] - model.get("target", 0)))])
    env.close()
    return np.asarray(rows)


def train_normal(lr, seed, random_policy=False, episodes=200):
    """REINFORCE, with one batched gradient evaluation per episode."""
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    policy = Policy(4, 2)
    optimizer = torch.optim.Adam(policy.parameters(), lr=lr)
    env = gym.make("CartPole-v1", max_episode_steps=200)
    env.action_space.seed(seed)
    history = []
    for episode in range(episodes):
        state, _ = env.reset(seed=seed if episode == 0 else None)
        observations, actions = [], []
        w1, b1, w2, b2 = [p.detach().numpy() for p in policy.parameters()]
        while True:
            logits = w2 @ np.maximum(w1 @ state + b1, 0) + b2
            prob = 1 / (1 + np.exp(np.clip(logits[0] - logits[1], -80, 80)))
            action = env.action_space.sample() if random_policy else int(rng.random() < prob)
            observations.append(state)
            actions.append(action)
            state, _, terminated, truncated, _ = env.step(action)
            if terminated or truncated:
                break
        n = len(actions)
        history.append(n)
        returns = torch.tensor((1 - .98**np.arange(n, 0, -1)) / .02, dtype=torch.float32)
        returns = (returns - returns.mean()) / returns.std().clamp_min(1e-8)
        probs = policy(torch.from_numpy(np.asarray(observations)))
        chosen = probs[torch.arange(n), torch.tensor(actions, dtype=torch.long)]
        loss = -(chosen.clamp_min(1e-12).log() * returns).mean()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    env.close()
    return {"mode": "normal", "weights": policy.state_dict()}, history


def train_feedback(mode, seed, episodes, target=0):
    """Fine-tune the supplied Policy with discounted REINFORCE on shaped returns."""
    from scipy.signal import lfilter
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    policy = Policy(4, 2)
    # Two opposite ReLU units encode a stabilizing initial feedback rule.
    # The other ten units retain their random initialization; Adam updates all units.
    with torch.no_grad():
        gain = torch.tensor([0.83516, 1.52066, 17.68685, 3.26663] if mode == "shuttle" else [1., 2., 18., 4.])
        policy.fc1.weight[0] = gain
        policy.fc1.weight[1] = -gain
        policy.fc2.weight[:, :2] = torch.tensor([[-3., 3.], [3., -3.]])
    optimizer = torch.optim.Adam(policy.parameters(), lr=.00002 if mode == "shuttle" else .0002)
    env = gym.make("CartPole-v1", max_episode_steps=500)
    history = []
    for episode in range(episodes):
        state, _ = env.reset(seed=seed if episode == 0 else None)
        direction = 1
        observations, actions, rewards = [], [], []
        w1, b1, w2, b2 = [p.detach().numpy() for p in policy.parameters()]
        while True:
            goal = direction * 1.8 if mode == "shuttle" else target
            features = state.copy()
            features[0] -= goal
            logits = w2 @ np.maximum(w1 @ features + b1, 0) + b2
            prob = 1 / (1 + np.exp(np.clip(logits[0] - logits[1], -60, 60)))
            action = int(rng.random() < prob)
            state, _, term, trunc, _ = env.step(action)
            observations.append(features)
            actions.append(action)
            rewards.append(reward_value(mode, state, goal, direction))
            if mode == "shuttle" and direction * state[0] >= 1.6:
                direction *= -1
            if term or trunc:
                break
        history.append(float(sum(rewards)))
        discounted = lfilter([1.], [1., -.98], rewards[::-1])[::-1].copy()
        returns = torch.tensor(discounted, dtype=torch.float32)
        returns = (returns - returns.mean()) / returns.std().clamp_min(1e-8)
        probs = policy(torch.from_numpy(np.asarray(observations)))
        chosen = probs[torch.arange(len(actions)), actions]
        loss = -(chosen.clamp_min(1e-12).log() * returns).mean()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    env.close()
    return dict(mode=mode, weights=policy.state_dict(), target=target,
                amplitude=1.8, threshold=1.6), history


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("-t", "--test")
    p.add_argument("--render_test", action="store_true")
    p.add_argument("--mode", choices=["normal", "center", "target", "shuttle"], default="normal")
    p.add_argument("--central_point", type=float, default=0.)
    p.add_argument("--train_episodes", type=int, default=200)
    p.add_argument("--lr", type=float, default=.01)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--random_policy", action="store_true")
    args = p.parse_args()
    if args.test:
        model = torch.load(args.test, map_location="cpu")
        print("Mean length, return, peak speed, switches, xmin, xmax, MAE:")
        print(evaluate(model, render=args.render_test).mean(axis=0))
    else:
        if args.mode == "normal":
            model, history = train_normal(args.lr, args.seed, args.random_policy, args.train_episodes)
        else:
            model, history = train_feedback(args.mode, args.seed, args.train_episodes,
                                           args.central_point if args.mode == "target" else 0.)
        torch.save(model, args.mode + ".ai")



def rollout_trace(model_file, seed):
    """Record the post-action states of a saved custom neural policy."""
    model = torch.load(model_file, map_location="cpu")
    policy = Policy(4, 2)
    policy.load_state_dict(model["weights"])
    env = gym.make("CartPole-v1", max_episode_steps=500)
    state, _ = env.reset(seed=seed)
    direction = 1
    path = []
    with torch.no_grad():
        while True:
            features = state.copy()
            goal = direction * model["amplitude"] if model["mode"] == "shuttle" else model["target"]
            features[0] -= goal
            action = policy(torch.from_numpy(features)).argmax().item()
            state, _, term, trunc, _ = env.step(action)
            path.append(state.copy())
            if model["mode"] == "shuttle" and direction * state[0] >= model["threshold"]:
                direction *= -1
            if term or trunc:
                break
    env.close()
    return np.asarray(path)

